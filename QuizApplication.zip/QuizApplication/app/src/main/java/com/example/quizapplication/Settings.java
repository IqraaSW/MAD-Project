package com.example.quizapplication;

import android.app.Activity;

public
class Settings extends Activity {
}
