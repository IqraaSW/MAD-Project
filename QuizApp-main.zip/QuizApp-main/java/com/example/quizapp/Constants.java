package com.example.quizapp;

public class Constants {

    public static final boolean  DEFAULT_MUSIC_SETTING=false;

    public static final String COINS="Total Coins: ";
    public static final String TOTAL_QUESTIONS="Total Questions: ";
    public static final String WRONG="Wrong Questions: ";
    public static final String CORRECT="Correct Questions: ";

}
